# EV3 forklift B0.1 - first physical build candidate

Start with [the assembly guide](design/build_candidate/BUILD-GUIDE.html), then open [the offline 3D viewer](design/build_candidate/EV3-Build-Candidate.html).

The package contains 21 assembly stages, exact CAD and placements, 329 physical LEGO pieces in the bill, sensor brackets, a lift trigger, adjustable stops and a camera holder. Choose an assembly step in the viewer; blue marks new parts, and the isolate checkbox shows that subassembly. Drag to rotate and scroll to zoom.

All 80 recorded geometry checks and five browser cases pass. This is a model for the first lab assembly, not a physically demonstrated build. Camera identity/interface, kit stock, switch trip/travel, stiffness, cable sweep and loaded stability require the acceptance tests in the guide. The camera envelope is assumed at 40 x 30 x 24 mm. No measured payload rating or navigation software is included.

The prior I0.3 version is preserved in design/saved with its SHA-256 manifest. Do not mix its motor spacing or gear-plane placement with B0.1.

The HTML viewer and MPD work independently offline. Regeneration sources and the LDraw subset are under design/cad; Python requires numpy and matplotlib. From this extracted root run build_candidate.py, audit_structure.py, verify_candidate.py and write_candidate_guide.py using their full design/cad paths, in that order. Browser checks require Chrome on Windows. Source geometry retains its LDraw author and license headers; see ATTRIBUTION.md in the build folder.
